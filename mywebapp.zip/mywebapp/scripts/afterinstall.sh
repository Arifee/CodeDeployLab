#!/bin/bash
npm install
 
#GULP COMMANDS
gulp scss
gulp cpk-scss
gulp compile
